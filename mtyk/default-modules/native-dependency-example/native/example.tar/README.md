# C++ Hello World
Hello world in C++ with VSCode, MinGW and Make

![alt-tag](screen.png)